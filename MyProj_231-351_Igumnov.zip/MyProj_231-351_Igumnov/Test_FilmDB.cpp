#include <gtest/gtest.h>
#include "FilmDB.h"

TEST(FilmDBTest, GetGoodFilmsOfGenre) {
    FilmDB db;
    db.addFilm("Inception", "Sci-Fi", 9, 148);
    db.addFilm("The Matrix", "Sci-Fi", 8, 136);
    db.addFilm("Interstellar", "Sci-Fi", 10, 169);

    auto result = db.get_good_films_of_genre(9, "Sci-Fi");
    ASSERT_EQ(result.size(), 2);
    EXPECT_EQ(result[0], "Inception");
    EXPECT_EQ(result[1], "Interstellar");
}


