#include <iostream>
#include "FilmDB.h"

int main() {
    FilmDB db;
    db.addFilm("Inception", "Sci-Fi", 9, 148);
    db.addFilm("The Dark Knight", "Action", 9, 152);
    db.addFilm("The Godfather", "Crime", 10, 175);
    db.addFilm("The Matrix", "Sci-Fi", 8, 136);

    std::vector<std::string> goodSciFi = db.get_good_films_of_genre(8, "Sci-Fi");
    std::cout << "Good Sci-Fi Films:\n";
    for (const auto& film : goodSciFi) {
        std::cout << film << std::endl;
    }

    return 0;
}

