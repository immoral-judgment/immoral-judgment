#include "FilmDB.h"

// Конструктор
FilmDB::FilmDB() {
    // Можно добавить начальные данные
}

// Метод для добавления фильма
void FilmDB::addFilm(const std::string& title, const std::string& genre, int rating, int time) {
    films.push_back({title, genre, rating, time});
}

// Метод для получения хороших фильмов заданного жанра
std::vector<std::string> FilmDB::get_good_films_of_genre(int rating, const std::string& genre) {
    std::vector<std::string> result;
    for (const auto& film : filterByGenre(genre)) {
        if (film.rating >= rating) {
            result.push_back(film.title);
        }
    }
    return result;
}

// Метод для получения фильмов заданного жанра меньше заданного времени
std::vector<std::string> FilmDB::get_films_of_genre_less_than(int time, const std::string& genre) {
    std::vector<std::string> result;
    for (const auto& film : filterByGenre(genre)) {
        if (film.time <= time) {
            result.push_back(film.title);
        }
    }
    return result;
}

// Метод для получения фильмов меньше заданного времени
std::vector<std::string> FilmDB::get_films_less_than(int time) {
    std::vector<std::string> result;
    for (const auto& film : films) {
        if (film.time <= time) {
            result.push_back(film.title);
        }
    }
    return result;
}

// Метод для подсчета количества фильмов заданного жанра
int FilmDB::count_genre(const std::string& genre) {
    int count = 0;
    for (const auto& film : films) {
        if (film.genre == genre) {
            count++;
        }
    }
    return count;
}

// Вспомогательный метод для фильтрации фильмов по жанру
std::vector<FilmDB::Film> FilmDB::filterByGenre(const std::string& genre) {
    std::vector<Film> filtered;
    for (const auto& film : films) {
        if (film.genre == genre) {
            filtered.push_back(film);
        }
    }
    return filtered;
}

